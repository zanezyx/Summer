package com.bf.duomi.bean.response;

import com.bf.duomi.commication.BaseResponse;

public class GetMessageCodeResponse extends BaseResponse {

	public GetMessageCodeResponse() {
		super();
	}
}
