package com.bf.duomi.entity;

public class IndexNew {

	public String content;
	public CreateDate createDate;
	public Integer hits;
	public Integer id;
	public String newLogo;
	public String newLogoUrl;
	public Integer status;
	public String title;
	

}
