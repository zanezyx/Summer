package com.bf.duomi.holder;

import android.widget.ImageView;
import android.widget.TextView;

public final class ProduceHolder{
    public ImageView image;
    public TextView name;
    public TextView productId;
    public TextView info;
    public TextView price;
}