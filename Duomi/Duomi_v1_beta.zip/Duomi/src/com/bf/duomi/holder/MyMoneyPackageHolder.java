package com.bf.duomi.holder;

import android.widget.TextView;

public final class MyMoneyPackageHolder{
    public TextView title;
   
}