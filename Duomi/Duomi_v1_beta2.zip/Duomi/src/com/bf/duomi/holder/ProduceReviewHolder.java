package com.bf.duomi.holder;

import android.widget.RatingBar;
import android.widget.TextView;

public final class ProduceReviewHolder{
    public TextView name;
    public TextView date;
    public TextView info;
    public RatingBar ratingBar;
}