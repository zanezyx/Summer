package com.bf.duomi.holder;

import android.widget.ImageView;
import android.widget.TextView;

public final class OrderProductHolder{
	public ImageView icon;
    public TextView name;
    public TextView price;
    public TextView count;
}