package com.bf.duomi.entity;

public class CreateDate {

	public Integer date;
	public Integer day;
	public Integer hours;
	public Integer minutes;
	public Integer month;
	public Integer seconds;
	public Long time;
	public Integer timezoneOffset;
	public Integer year;
}
