package com.bf.duomi.entity;


public class ProductSecondary implements java.io.Serializable {

	// Fields

	/**
	 * 
	 */
	private static final long serialVersionUID = 5328771303609042648L;
	public Integer id;
	public String code;
	public String name;
	public Integer productType;

	// Constructors

	/** default constructor */
	public ProductSecondary() {
	}

	/** full constructor */
//	public ProductSecondary(String code, String content, Integer state, String name,
//			String remark) {
//		this.code = code;
//		this.content = content;
//		this.state = state;
//		this.name = name;
//		this.remark = remark;
//	}


}