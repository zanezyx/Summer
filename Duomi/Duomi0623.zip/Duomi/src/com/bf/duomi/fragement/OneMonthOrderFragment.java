package com.bf.duomi.fragement;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.bf.duomi.activity.MyOrderDetailActivity;
import com.bf.duomi.adapter.OneMonthAdapter;
import com.bf.duomi.bean.request.OneMonthRequest;
import com.bf.duomi.bean.response.OneMonthResponse;
import com.bf.duomi.commication.BaseRequest;
import com.bf.duomi.commication.BaseResponse;
import com.bf.duomi.entity.TOrderToJson;
import com.bf.duomi.service.OneMonthService;
import com.bf.duomi.util.AppUtil;
import com.bf.duomi.util.NetListener;
import com.bf.duomi.R;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.StrictMode;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;

/**
 * 近一个月订单
 * 
 * @author lenovo
 * 
 */
public class OneMonthOrderFragment extends Fragment {

	private List<Map<String, Object>> mData;
	private ListView orderlist;
	private Context context;

	private OneMonthResponse oneMonthResponse;
	private OneMonthRequest oneMonthRequest;
	private OneMonthService oneMonthService;

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {

		View rootView = inflater.inflate(R.layout.fragment_one_month_order,
				null);
		context = rootView.getContext();
		orderlist = (ListView) rootView.findViewById(R.id.onemonthorder);
		OnloadData();
		orderlist.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> arg0, View arg1, int arg2,
					long arg3) {
				Bundle bundle = new Bundle();
				bundle.putInt("orderId", Integer.valueOf(mData.get(arg2).get("orderId").toString()));
				Intent intent = new Intent();
				intent.putExtras(bundle);
				intent.setClass(context, MyOrderDetailActivity.class);
				context.startActivity(intent);
			}
		});
		return rootView;
	}

	/**
	 * 获取数据
	 * 
	 * @return
	 */
	private List<Map<String, Object>> getData() {
		List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();

		if (oneMonthResponse != null && oneMonthResponse.getData() != null
				&& oneMonthResponse.getData().size() > 0) {
			List<TOrderToJson> orderlist = oneMonthResponse.getData();
			for (TOrderToJson order : orderlist) {
				Map<String, Object> map = new HashMap<String, Object>();
				map.put("orderId", order.getId());
				map.put("number", "订单号： " + order.id);
				map.put("orderMoney", "￥： " + order.getTotalPrice());
				map.put("orderDate", "下单时间： " + order.getPublishDate());
				String state = "待处理";
				switch (order.getOrderStatus()) {
				case 1:
					state = "待处理";
					break;
				case 2:
					state = "处理中";
					break;
				case 3:
					state = "完成";
					break;
				case 4:
					state = "作废";
					break;
				}
				map.put("orderstate", state);
				list.add(map);
			}
			return list;
		}

		return null;

	}

	/**
	 * 通过网络获取数据
	 */
	@SuppressLint("NewApi")
	public void OnloadData() {
		try {
			StrictMode.setThreadPolicy(new StrictMode.ThreadPolicy.Builder()
					.detectDiskReads().detectDiskWrites().detectNetwork()
					.penaltyLog().build());
			StrictMode.setVmPolicy(new StrictMode.VmPolicy.Builder()
					.detectLeakedSqlLiteObjects().detectLeakedClosableObjects()
					.penaltyLog().penaltyDeath().build());
			oneMonthRequest = new OneMonthRequest();
			oneMonthRequest.setCustomId(1);
//			oneMonthRequest.setPageNo(1);
			oneMonthService = new OneMonthService(context);
			oneMonthService.setRequest(oneMonthRequest);
			oneMonthService.request(new NetListener() {
				@Override
				public void onPrepare() {
				}

				@Override
				public void onLoading() {
				}

				@Override
				public void onLoadSuccess(BaseResponse response) {
					mData = getData();
					OneMonthAdapter adapter = new OneMonthAdapter(orderlist
							.getContext(), mData);
					orderlist.setAdapter(adapter);
					AppUtil.showInfoShort(context, "获取近一个月订单成功！");
				}

				@Override
				public void onFailed(Exception ex, BaseResponse response) {
					AppUtil.showInfoShort(context, "获取近一个月订单失败！");
				}

				@Override
				public void onComplete(String respondCode, BaseRequest request,
						BaseResponse response) {
					oneMonthResponse = (OneMonthResponse) response;
					oneMonthService.setResponse(oneMonthResponse);
				}

				@Override
				public void onCancel() {
				}
			});
		} catch (Exception e) {
			Log.e("oneMonthService error!", "oneMonthService onload error!");
		}
	}
}
