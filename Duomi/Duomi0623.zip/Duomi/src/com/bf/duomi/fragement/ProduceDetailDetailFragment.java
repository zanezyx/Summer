package com.bf.duomi.fragement;

import com.bf.duomi.bean.request.SingleProduceRequest;
import com.bf.duomi.bean.response.SingleProduceResponse;
import com.bf.duomi.commication.BaseRequest;
import com.bf.duomi.commication.BaseResponse;
import com.bf.duomi.entity.Product;
import com.bf.duomi.service.SingleProduceService;
import com.bf.duomi.util.AppUtil;
import com.bf.duomi.util.NetListener;
import com.bf.duomi.R;

import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

/**
 * 商品详情
 * 
 * @author lenovo
 * 
 */
public class ProduceDetailDetailFragment extends Fragment {

	private TextView type, brand, content, storemethod, Shelflife, license;

	private Context mContext;

	private SingleProduceRequest sproduceRequest;
	private SingleProduceService sProduceService;
	private SingleProduceResponse sProduceResponse;

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {

		View rootView = inflater.inflate(
				R.layout.fragment_produce_detail_detail, null);

		mContext = rootView.getContext();

		type = (TextView) rootView.findViewById(R.id.type);
		brand = (TextView) rootView.findViewById(R.id.brand);
		content = (TextView) rootView.findViewById(R.id.content);
		storemethod = (TextView) rootView.findViewById(R.id.storemethod);
		Shelflife = (TextView) rootView.findViewById(R.id.Shelflife);
		license = (TextView) rootView.findViewById(R.id.license);
		load(AppUtil.getProduceID());
		return rootView;
	}

	/**
	 * 加载数据
	 * 
	 * @throws Exception
	 */
	public void load(final int id) {
		try {
			sproduceRequest = new SingleProduceRequest();
			sproduceRequest.setContext(mContext);
			sproduceRequest.setId(id);
			sProduceService = new SingleProduceService(mContext);
			sProduceService.setRequest(sproduceRequest);
			sProduceService.request(new NetListener() {
				@Override
				public void onPrepare() {
				}

				@Override
				public void onLoading() {
				}

				@Override
				public void onLoadSuccess(BaseResponse response) {
					if (sProduceResponse != null) {
						try {
							Product product = sProduceResponse.getProduct();
							type.setText(sProduceResponse.getProductType().getName());
							brand.setText(product.getBrand().toString());
							content.setText((product.getNorm() + product.getUnit()).toString());
							storemethod.setText("");
							Shelflife.setText("");
							license.setText(product.getCode().toString());
						} catch (Exception e) {
							// TODO: handle exception
							AppUtil.showInfoShort(mContext, "获取产品信息出错");
						}
					}
					AppUtil.showInfoShort(mContext, "获取产品信息成功");
				}

				@Override
				public void onFailed(Exception ex, BaseResponse response) {
					AppUtil.showInfoShort(mContext, "获取产品信息失败");
				}

				@Override
				public void onComplete(String respondCode, BaseRequest request,
						BaseResponse response) {
					sProduceResponse = (SingleProduceResponse) response;
					sProduceService.setResponse(sProduceResponse);
				}

				@Override
				public void onCancel() {
				}
			});
		} catch (Exception e) {
			Log.e("produceDetail error!", "produceDetail load data error!");
		}
	}

}
