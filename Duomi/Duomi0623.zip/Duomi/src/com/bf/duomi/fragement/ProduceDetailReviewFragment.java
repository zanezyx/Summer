package com.bf.duomi.fragement;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.bf.duomi.adapter.ProduceReviewAdapter;
import com.bf.duomi.R;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

/**
 * 商品评论
 * 
 * @author lenovo
 * 
 */
public class ProduceDetailReviewFragment extends Fragment {
	
	private List<Map<String, Object>> mData ;
	private ListView reviewlist;
	
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {

		View rootView = inflater.inflate(R.layout.fragment_produce_detail_review, null);
		
		reviewlist = (ListView) rootView.findViewById(R.id.reviewlist);

//		mData = getData();
//		ProduceReviewAdapter adapter = new ProduceReviewAdapter(reviewlist.getContext(), mData);
//		reviewlist.setAdapter(adapter);
		
		return rootView;
	}

	/**
	 * 获取数据
	 * @return
	 */
	private List<Map<String, Object>> getData() {
		List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();

		Map<String, Object> map = new HashMap<String, Object>();
		map.put("name", "G1");
		map.put("info", "google 1");
		map.put("date", "2014-01-12");
		map.put("ratingBar", "2");
		list.add(map);

		map = new HashMap<String, Object>();
		map.put("name", "G2");
		map.put("info", "google 2");
		map.put("date", "2014-01-12");
		map.put("ratingBar", "2.5");
		list.add(map);

		map = new HashMap<String, Object>();
		map.put("name", "G3");
		map.put("info", "google 3");
		map.put("date", "2014-01-12");
		map.put("ratingBar", "3.5");
		list.add(map);

		return list;
	}
}
