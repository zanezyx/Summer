package com.bf.duomi.adapter;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.bf.duomi.holder.ProduceChangeHolder;
import com.bf.duomi.R;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

/**
 * 自定义适配器
 * @author lenovo
 *
 */
public class ProduceChangeRecordAdapter extends BaseAdapter{
	 
    private LayoutInflater mInflater;
    private List<Map<String, Object>> mData = new ArrayList<Map<String,Object>>();
     
    public ProduceChangeRecordAdapter(Context context, List<Map<String, Object>> mData){
        this.mInflater = LayoutInflater.from(context);
        this.mData = mData;
    }
    //获得记录数
    @Override
    public int getCount() {
    	if(mData != null){
			return mData.size();
		}
		return 0;
    }

    @Override
    public Object getItem(int arg0) {
        return null;
    }

    @Override
    public long getItemId(int arg0) {
        return 0;
    }

    /**
     * 重写记录
     */
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
         
        ProduceChangeHolder holder = null;
        if (convertView == null) {
            holder=new ProduceChangeHolder();  
            convertView = mInflater.inflate(R.layout.producechangerecord_list_item_view, null);
            holder.name = (TextView)convertView.findViewById(R.id.name);
            holder.date = (TextView)convertView.findViewById(R.id.date);
            holder.state = (TextView)convertView.findViewById(R.id.state);
            holder.detail = (TextView) convertView.findViewById(R.id.detail);
            convertView.setTag(holder);
        }
        else {
            holder = (ProduceChangeHolder)convertView.getTag();
        }
         
        holder.name.setText((String)mData.get(position).get("name"));
        holder.date.setText((String)mData.get(position).get("date"));
        holder.state.setText((String)mData.get(position).get("state"));
        holder.detail.setText((String)mData.get(position).get("detail"));
        return convertView;
    }
     
}
