package com.bf.duomi.adapter;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.bf.duomi.holder.ProduceAdvistryHolder;
import com.bf.duomi.R;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

/**
 * 自定义适配器
 * @author lenovo
 *
 */
public class ProduceAdvistryAdpter extends BaseAdapter{
	 
    private LayoutInflater mInflater;
    private List<Map<String, Object>> mData = new ArrayList<Map<String,Object>>();
     
    public ProduceAdvistryAdpter(Context context, List<Map<String, Object>> mData){
        this.mInflater = LayoutInflater.from(context);
        this.mData = mData;
    }
    //获得记录数
    @Override
    public int getCount() {
    	if(mData != null){
			return mData.size();
		}
		return 0;
    }

    @Override
    public Object getItem(int arg0) {
        return null;
    }

    @Override
    public long getItemId(int arg0) {
        return 0;
    }

    /**
     * 重写记录
     */
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
         
        ProduceAdvistryHolder holder = null;
        if (convertView == null) {
            holder = new ProduceAdvistryHolder();  
            convertView = mInflater.inflate(R.layout.produceadvistry_list_item_view, null);
            holder.name = (TextView)convertView.findViewById(R.id.name);
            holder.date = (TextView)convertView.findViewById(R.id.date);
            holder.request = (TextView)convertView.findViewById(R.id.request);
            holder.answer = (TextView) convertView.findViewById(R.id.answer);
            convertView.setTag(holder);
        }
        else {
            holder = (ProduceAdvistryHolder)convertView.getTag();
        }
         
        holder.name.setText((String)mData.get(position).get("name"));
        holder.date.setText((String)mData.get(position).get("date"));
        holder.request.setText((String)mData.get(position).get("request"));
        holder.answer.setText((String)mData.get(position).get("answer"));
        return convertView;
    }
     
}
