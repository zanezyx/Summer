package com.bf.duomi.adapter;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.bf.duomi.holder.ViewProduceHolder;
import com.bf.duomi.R;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

/**
 * 自定义产品适配器
 * 
 * @author bhl
 * 
 */
public class ViewProduceAdapter extends BaseAdapter {

	private LayoutInflater mInflater;
	private List<Map<String, Object>> mData = new ArrayList<Map<String, Object>>();

	public ViewProduceAdapter(Context context, List<Map<String, Object>> mData) {
		this.mInflater = LayoutInflater.from(context);
		this.mData = mData;
	}

	// 获得记录数
	@Override
	public int getCount() {
		if(mData != null){
			return mData.size();
		}
		return 0;
	}

	@Override
	public Object getItem(int arg0) {
		return null;
	}

	@Override
	public long getItemId(int arg0) {
		return 0;
	}

	/**
	 * 重写记录
	 */
	@Override
	public View getView(int position, View convertView, ViewGroup parent) {

		ViewProduceHolder holder = null;
		if (convertView == null) {
			holder = new ViewProduceHolder();
			convertView = mInflater.inflate(
					R.layout.viewproduce_list_item_view, null);
			holder.ico = (ImageView) convertView.findViewById(R.id.ico);
			holder.title = (TextView) convertView.findViewById(R.id.title);
			holder.info = (TextView) convertView.findViewById(R.id.info);
			holder.price = (TextView) convertView.findViewById(R.id.price);
			convertView.setTag(holder);
		} 
		else {
			holder = (ViewProduceHolder) convertView.getTag();
		}
//		LoadImageUtil loadImage = new LoadImageUtil();
		// Log.i("error!",
		// "-------------imagepath : "
		// + (PropertiesUtils.getProperties().getProperty(
		// "IMAGA_SERVICE_URL") + mData.get(position).get(
		// "ico")));
		// loadImage.showImageAsyn(
		// holder.ico,
		// String.valueOf(PropertiesUtils.getProperties().getProperty(
		// "IMAGA_SERVICE_URL")
		// + mData.get(position).get("ico")), R.drawable.icon);
		holder.ico.setImageResource(R.drawable.pictureimages);
		// holder.ico.setImageUrl(String.valueOf(PropertiesUtils.getProperties().getProperty(
		// "IMAGA_SERVICE_URL"+ (String) mData.get(position).get("ico"));
		holder.title.setText((String) mData.get(position).get("title"));
		holder.info.setText(mData.get(position).get("info").toString());
		holder.price.setText(mData.get(position).get("price").toString());
		return convertView;
	}

}
