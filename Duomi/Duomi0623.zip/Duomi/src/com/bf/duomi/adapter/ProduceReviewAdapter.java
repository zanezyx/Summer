package com.bf.duomi.adapter;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.bf.duomi.holder.ProduceReviewHolder;
import com.bf.duomi.R;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.RatingBar;
import android.widget.TextView;

/**
 * 浏览 自定义适配器
 * @author lenovo
 *
 */
public class ProduceReviewAdapter extends BaseAdapter{
	 
    private LayoutInflater mInflater;
    private List<Map<String, Object>> mData = new ArrayList<Map<String,Object>>();
     
    public ProduceReviewAdapter(Context context, List<Map<String, Object>> mData){
        this.mInflater = LayoutInflater.from(context);
        this.mData = mData;
    }
    //获得记录数
    @Override
    public int getCount() {
    	if(mData != null){
			return mData.size();
		}
		return 0;
    }

    @Override
    public Object getItem(int arg0) {
        return null;
    }

    @Override
    public long getItemId(int arg0) {
        return 0;
    }

    /**
     * 重写记录
     */
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
         
        ProduceReviewHolder holder = null;
        if (convertView == null) {
            holder=new ProduceReviewHolder();  
            convertView = mInflater.inflate(R.layout.producereview_list_item_view, null);
            holder.name = (TextView)convertView.findViewById(R.id.name);
            holder.date = (TextView)convertView.findViewById(R.id.date);
            holder.info = (TextView)convertView.findViewById(R.id.info);
            holder.ratingBar = (RatingBar) convertView.findViewById(R.id.ratingBar);
            convertView.setTag(holder);
        }
        else {
            holder = (ProduceReviewHolder)convertView.getTag();
        }
         
        holder.name.setText((String)mData.get(position).get("name"));
        holder.date.setText((String)mData.get(position).get("date"));
        holder.ratingBar.setRating(Float.valueOf(mData.get(position).get("ratingBar").toString()));
        holder.info.setText((String)mData.get(position).get("info"));
        return convertView;
    }
     
}
