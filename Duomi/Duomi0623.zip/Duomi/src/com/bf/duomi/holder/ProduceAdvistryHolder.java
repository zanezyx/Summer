package com.bf.duomi.holder;

import android.widget.TextView;

public final class ProduceAdvistryHolder{
    public TextView name;
    public TextView date;
    public TextView request;
    public TextView answer;
}