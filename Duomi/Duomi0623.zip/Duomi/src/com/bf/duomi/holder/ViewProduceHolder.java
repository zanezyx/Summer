package com.bf.duomi.holder;

import android.widget.ImageView;
import android.widget.TextView;

public final class ViewProduceHolder{
    public ImageView ico;
    public TextView title;
    public TextView info;
    public TextView price;
}