package com.bf.duomi.holder;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public final class SelectAddressHolder{
	public View remove;
	public TextView name;
    public TextView addresss;
    public TextView addresssDetail;
    public TextView phone;
    public TextView isDefault;
    public ImageView editAddress;
}