package com.bf.duomi.constant;

public class SysConstant {
	public static final String CACHE_IMAGE_FOLDER = "/ImageCache";
	
	public static final String CACHE_IMAGE_THUMB_FOLDER = "/ImageThumbCache";
}
