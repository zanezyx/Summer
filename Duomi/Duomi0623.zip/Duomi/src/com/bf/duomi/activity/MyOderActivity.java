package com.bf.duomi.activity;

import com.bf.duomi.R;
import com.bf.duomi.fragement.BeforeMonthOrderFragment;
import com.bf.duomi.fragement.OneMonthOrderFragment;


import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentTabHost;
import android.view.Window;
import android.widget.TabHost.OnTabChangeListener;
import android.widget.TabHost.TabSpec;

/**
 * 我的订单
 * 
 * @author lenovo
 * 
 */
public class MyOderActivity extends FragmentActivity {
	// 定义FragmentTabHost对象
	private FragmentTabHost mTabHost;

	// 定义数组来存放Fragment界面
	private Class fragmentArray[] = { OneMonthOrderFragment.class,
			BeforeMonthOrderFragment.class };

	// 定义数组来存放按钮图片
	private int mImageViewArray[] = { R.drawable.onemonth,
			R.drawable.beforemonth };

	// Tab选项卡的文字
	private String mTextviewArray[] = { "近一个月订单", "一个月前订单"};

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		requestWindowFeature(Window.FEATURE_NO_TITLE);//无标题栏 
		setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);//不能横屏
		
		setContentView(R.layout.myorder_activity);
		init();
	}
	
	/**
	 * 初始化界面
	 */
	public final void init() {
		// 实例化TabHost对象，得到TabHost
		mTabHost = (FragmentTabHost) findViewById(android.R.id.tabhost);
		mTabHost.setup(this, getSupportFragmentManager(), android.R.id.tabcontent);

		// fragment的个数
		final int count = fragmentArray.length;
		for (int i = 0; i < count; i++) {
			// 为每一个Tab按钮设置图标、文字和内容
			final TabSpec tabSpec = mTabHost.newTabSpec(mTextviewArray[i]).setIndicator(mTextviewArray[i]);
			// 将Tab按钮添加进Tab选项卡中
			mTabHost.addTab(tabSpec, fragmentArray[i], null);
			//默认为商品详情
			if (i == 0) {
				mTabHost.setCurrentTab(i);
			} 
			// 设置Tab按钮的背景
			mTabHost.getTabWidget().getChildAt(i)
					.setBackgroundResource(mImageViewArray[i]);
		}

		mTabHost.setOnTabChangedListener(new tabChangeClick());
	}

	/**
	 * tab改变事件
	 * 
	 * @author lenovo
	 * 
	 */
	private final class tabChangeClick implements OnTabChangeListener {
		// 灰色图片
		final int[] imageBackArray = new int[] {
				R.drawable.produce_detail_base_bank,
				 };
		// 正常图片
		final int[] imageArray = new int[] { R.drawable.produce_detail_base,
				R.drawable.produce_detail_detail,
				 };

		final String mTextviewArray[] = { "近一个月订单", "商品详情" };

		@Override
		public void onTabChanged(String arg0) {
			for (int i = 0; i < mTextviewArray.length; i++) {
				// 选中tab
				if (arg0 == mTextviewArray[i]) {
					mTabHost.getTabWidget().getChildAt(i)
							.setBackgroundResource(imageArray[i]);
				} else
					mTabHost.getTabWidget().getChildAt(i)
							.setBackgroundResource(imageBackArray[i]);
			}
		}
	}
}
