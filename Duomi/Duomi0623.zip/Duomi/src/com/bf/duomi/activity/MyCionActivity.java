package com.bf.duomi.activity;

import com.bf.duomi.R;
import com.bf.duomi.bean.request.MyCionRequest;
import com.bf.duomi.bean.response.MyCionResponse;
import com.bf.duomi.commication.BaseRequest;
import com.bf.duomi.commication.BaseResponse;
import com.bf.duomi.service.MyCionService;
import com.bf.duomi.util.AppUtil;
import com.bf.duomi.util.NetListener;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.os.StrictMode;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

/**
 * 我的余额
 * @author bhl
 * 
 */
public class MyCionActivity extends BaseActivity {
	private ImageView back;
	private Context mContext;
	private TextView ciontext;
	private MyCionResponse myCionResponse;
	private MyCionRequest myCionRequest;
	private MyCionService myCionService;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);//无标题栏 
		setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);//不能横屏
		setContentView(R.layout.mycion_activity);
		mContext = this;
		init();
		loadData();
	}

	/**
	 * 界面初始化
	 */
	public void init() {
		try {
			ciontext = (TextView) findViewById(R.id.ciontext);
			back = (ImageView) findViewById(R.id.back);
			
			back.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View arg0) {
					finish();
				}
			});
		} catch (Exception e) {
			Log.e("MyMoneyActivity error!", "MyMoneyActivity error!");
			Toast.makeText(this, "MyMoneyActivity error", Toast.LENGTH_LONG).show();
		}
	}
	
	/**
	 * 获取数据
	 */
	@SuppressLint("NewApi")
	public void loadData() {
		try {
			StrictMode.setThreadPolicy(new StrictMode.ThreadPolicy.Builder()
					.detectDiskReads().detectDiskWrites().detectNetwork()
					.penaltyLog().build());
			StrictMode.setVmPolicy(new StrictMode.VmPolicy.Builder()
					.detectLeakedSqlLiteObjects().detectLeakedClosableObjects()
					.penaltyLog().penaltyDeath().build());
			myCionRequest = new MyCionRequest();
			myCionRequest.setCustomId(1);
			myCionService = new MyCionService(mContext);
			myCionService.setRequest(myCionRequest);
			myCionService.request(new NetListener() {
				@Override
				public void onPrepare() {
				}

				@Override
				public void onLoading() {
				}

				@Override
				public void onLoadSuccess(BaseResponse response) {
					ciontext.setText(String.valueOf(myCionResponse.getWallet().getBeans()));
					AppUtil.showInfoShort(mContext, "获取我的农币成功！");
				}

				@Override
				public void onFailed(Exception ex, BaseResponse response) {
					AppUtil.showInfoShort(mContext, "获取我的农币失败！");
				}

				@Override
				public void onComplete(String respondCode, BaseRequest request,
						BaseResponse response) {
					myCionResponse = (MyCionResponse) response;
					myCionService.setResponse(myCionResponse);
				}

				@Override
				public void onCancel() {
				}
			});
		} catch (Exception e) {
			Log.e("MyMoneyActivity error!",
					"MyMoneyActivity onload error!");
		}
	}
}
