package com.bf.duomi.activity;

import java.util.List;

import com.bf.duomi.R;
import com.bf.duomi.bean.request.OrderDetailRequest;
import com.bf.duomi.bean.response.OrderDetailResponse;
import com.bf.duomi.commication.BaseRequest;
import com.bf.duomi.commication.BaseResponse;
import com.bf.duomi.entity.Cart;
import com.bf.duomi.entity.Custom;
import com.bf.duomi.entity.ReceiveAddress;
import com.bf.duomi.entity.TOrderToJson;
import com.bf.duomi.service.OrderDetailService;
import com.bf.duomi.util.AppUtil;
import com.bf.duomi.util.NetListener;


import android.annotation.SuppressLint;
import android.content.Context;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.os.StrictMode;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

/**
 * 订单详情
 * 
 * @author zyx
 * 
 */
public class MyOrderDetailActivity extends BaseActivity {
	private ImageView back;
	private Context mContext;
	private int orderId;
	private OrderDetailResponse orderDetailResponse;
	private OrderDetailRequest orderDetailRequest;
	private OrderDetailService orderDetailService;

	private TextView orderNumber, ordrtotalmoney, producetotalmoney,
			produceinfo, recerveAddress;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);// 无标题栏
		setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);// 不能横屏
		setContentView(R.layout.myorderdetail_activity);
		mContext = this;
		Bundle bundle = getIntent().getExtras();
		orderId = bundle.getInt("orderId");
		init();
		loadData();
	}

	/**
	 * 界面初始化
	 */
	public void init() {
		try {
			orderNumber = (TextView) this.findViewById(R.id.orderNumber);
			ordrtotalmoney = (TextView) this.findViewById(R.id.ordrtotalmoney);
			producetotalmoney = (TextView) this
					.findViewById(R.id.producetotalmoney);
			produceinfo = (TextView) this.findViewById(R.id.produceinfo);
			recerveAddress = (TextView) this.findViewById(R.id.recerveAddress);

			back = (ImageView) findViewById(R.id.back);
			back.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View arg0) {
					finish();
				}
			});
		} catch (Exception e) {
			Log.e("MyOrderDetailActivity error!",
					"MyOrderDetailActivity error!");
			Toast.makeText(this, "MyOrderDetailActivity error",
					Toast.LENGTH_LONG).show();
		}
	}

	/**
	 * 获取验证码
	 */
	@SuppressLint("NewApi")
	public void loadData() {
		try {
			StrictMode.setThreadPolicy(new StrictMode.ThreadPolicy.Builder()
					.detectDiskReads().detectDiskWrites().detectNetwork()
					.penaltyLog().build());
			StrictMode.setVmPolicy(new StrictMode.VmPolicy.Builder()
					.detectLeakedSqlLiteObjects().detectLeakedClosableObjects()
					.penaltyLog().penaltyDeath().build());
			orderDetailRequest = new OrderDetailRequest();
			orderDetailRequest.setId(orderId);
			orderDetailService = new OrderDetailService(mContext);
			orderDetailService.setRequest(orderDetailRequest);
			orderDetailService.request(new NetListener() {
				@Override
				public void onPrepare() {
				}

				@Override
				public void onLoading() {
				}

				@Override
				public void onLoadSuccess(BaseResponse response) {
					if (orderDetailResponse != null) {
//						List<Cart> carts = orderDetailResponse.getCarts();
//						TOrderToJson order = orderDetailResponse.getOrder();
//						ReceiveAddress address = orderDetailResponse
//								.getReceiveAddress();
//						Custom custom = orderDetailResponse.getCustom();
//						if (order != null) {
//							orderNumber.setText("订单编号： " + String.valueOf(order
//									.id));
//							ordrtotalmoney.setText(String.valueOf(order
//									.getTotalPrice()));
//							producetotalmoney.setText(String.valueOf(order
//									.getTotalPrice()));
//						}
//						StringBuffer prodeceContent = new StringBuffer();
//						if (carts != null && carts.size() > 0) {
//							for (Cart cart : carts) {
//							}
//						}
//
//						produceinfo.setText(String.valueOf(prodeceContent
//								.toString()));
//						if (address != null) {
//							recerveAddress.setText("收货地址 ：" + address.getProvince()
//									+ address.getCity() + address.getCountry()
//									+ address.getAddress());
//						}
					}

					AppUtil.showInfoShort(mContext, "获取订单详情成功！");
				}

				@Override
				public void onFailed(Exception ex, BaseResponse response) {
					AppUtil.showInfoShort(mContext, "获取订单详情失败！");
				}

				@Override
				public void onComplete(String respondCode, BaseRequest request,
						BaseResponse response) {
					orderDetailResponse = (OrderDetailResponse) response;
					orderDetailService.setResponse(orderDetailResponse);
				}

				@Override
				public void onCancel() {
				}
			});
		} catch (Exception e) {
			Log.e("MyOrderDetailActivity error!",
					"MyOrderDetailActivity onload error!");
		}
	}
}
