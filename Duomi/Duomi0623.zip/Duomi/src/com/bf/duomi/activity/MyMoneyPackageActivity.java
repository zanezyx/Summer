package com.bf.duomi.activity;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.bf.duomi.R;
import com.bf.duomi.adapter.MyMoneyPackageAdapter;
import com.bf.duomi.application.UserInfo;
import com.bf.duomi.util.DialogUtil;
import com.bf.duomi.util.SharePreferenceManager;


import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.Toast;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;

/**
 * 我的钱包
 * 
 * @author bhl
 * 
 */
public class MyMoneyPackageActivity extends BaseActivity {

	private ListView list;
	private List<Map<String, Object>> mData;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);// 无标题栏
		setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);// 不能横屏
		setContentView(R.layout.mymoneypackage_activity);
		init();
		mData = getData();
		MyMoneyPackageAdapter adapter = new MyMoneyPackageAdapter(this, mData);
		list.setAdapter(adapter);

	}

	/**
	 * 初始化界面
	 */
	public void init() {
		list = (ListView) findViewById(R.id.list);
		list.setOnItemClickListener(new OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> arg0, View arg1, int arg2,
					long arg3) {
				if (!UserInfo.getInstance().isLogin) {
						DialogUtil dialogUtil = new DialogUtil();
					dialogUtil.showAlertDialog(MyMoneyPackageActivity.this);

				} else {
					if (arg2 == 0) {
						Intent intent = new Intent();
						intent.setClass(MyMoneyPackageActivity.this,
								MyMoneyActivity.class);
						MyMoneyPackageActivity.this.startActivity(intent);
					}
					if (arg2 == 1) {
						Intent intent = new Intent();
						intent.setClass(MyMoneyPackageActivity.this,
								MyCionActivity.class);
						MyMoneyPackageActivity.this.startActivity(intent);
					}
				}
			}
		});
	}

	/**
	 * 获取数据
	 * 
	 * @return
	 */
	private List<Map<String, Object>> getData() {
		List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();

		Map<String, Object> map = new HashMap<String, Object>();
		map.put("title", "账户余额");
		list.add(map);

		map = new HashMap<String, Object>();
		map.put("title", "农币");
		list.add(map);

		map = new HashMap<String, Object>();
		map.put("title", "积分");
		list.add(map);

		map = new HashMap<String, Object>();
		map.put("title", "转入转出");
		list.add(map);

		return list;
	}
}
