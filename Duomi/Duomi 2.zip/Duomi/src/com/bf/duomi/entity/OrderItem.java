package com.bf.duomi.entity;

public class OrderItem {

	public Integer id;
	public Integer productId;
	public String productName;
	public String productImageUrl;
	public Integer amout;
	public Integer orderId;
	public Integer productPrice;
	
}
