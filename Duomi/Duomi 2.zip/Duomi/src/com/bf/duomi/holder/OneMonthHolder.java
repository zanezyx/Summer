package com.bf.duomi.holder;

import android.widget.Button;
import android.widget.TextView;

public final class OneMonthHolder{

    public TextView productName;
    public TextView orderMoney;
    public TextView name;
    public TextView mobile;
    public TextView receiverName;
    public TextView receiverMobile;
    public TextView receiverAddress;
    public TextView paymentType;
    public TextView deliverystate;
    public TextView orderDate;
    public TextView viewDetail;
    public Button pay;
    public Button cancelOrder;
    
}