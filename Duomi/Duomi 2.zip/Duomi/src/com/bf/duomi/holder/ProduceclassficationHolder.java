package com.bf.duomi.holder;

import android.widget.TextView;

public final class ProduceclassficationHolder{
    public TextView name;
    public TextView title;
    public TextView info;
}