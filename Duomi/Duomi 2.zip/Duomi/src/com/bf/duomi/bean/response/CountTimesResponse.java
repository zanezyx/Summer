package com.bf.duomi.bean.response;

import org.json.JSONException;
import org.json.JSONObject;

import android.util.Log;

import com.bf.duomi.application.UserInfo;
import com.bf.duomi.commication.BaseResponse;
import com.bf.duomi.entity.Custom;
import com.bf.duomi.entity.Product;

public class CountTimesResponse extends BaseResponse {

	
	public CountTimesResponse(){
		super();
	}
	
	
	public void parseResString()
	{

	}
	
}
