package com.bf.duomi.bean.response;

import com.bf.duomi.commication.BaseResponse;

public class RegisterResponse extends BaseResponse {

	public RegisterResponse() {
		super();
	}
}
