package com.bf.duomi.holder;

import android.widget.ImageView;
import android.widget.TextView;

public final class ProduceTypeHolder{
    public TextView name;
    public ImageView number;
    public TextView info;
    public TextView price;
}