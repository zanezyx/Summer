package com.bf.duomi.holder;

import android.widget.TextView;

public final class ProduceChangeHolder{
    public TextView name;
    public TextView date;
    public TextView state;
    public TextView detail;
}