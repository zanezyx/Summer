package com.bf.duomi.holder;

import android.widget.ImageView;
import android.widget.TextView;

public final class PersonCenterHolder{
    public ImageView remark;
    public TextView title;
   
}