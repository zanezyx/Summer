package com.bf.duomi.entity;

public class Address {

	public  String name, addressDetail,phone;
	public String strProvince, strCity, strCounty;
}
